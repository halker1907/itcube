# Задача № 2

import java.util.Scanner;

public class CompareStrings {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the first string: ");
        String firstString = scanner.nextLine();

        System.out.println("Enter the second string: ");
        String secondString = scanner.nextLine();

        boolean stringsEqual = firstString.equals(secondString);
        System.out.println(stringsEqual);
        
        scanner.close();
    }
}